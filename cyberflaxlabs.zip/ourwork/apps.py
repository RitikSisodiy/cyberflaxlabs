from django.apps import AppConfig


class OurworkConfig(AppConfig):
    name = 'ourwork'
